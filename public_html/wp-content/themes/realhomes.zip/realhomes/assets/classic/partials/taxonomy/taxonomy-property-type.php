<?php
/**
 * Taxonomy: Property Type
 *
 * @since 1.0.0
 * @package RH/classic
 */

// Use Common Taxonomy Template.
get_template_part( 'assets/classic/partials/taxonomy/taxonomy', 'common' );

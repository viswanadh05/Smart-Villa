<?php
/**
 * Taxonomy: Property Status
 *
 * @since 3.0.0
 * @package RH/Modern
 */

// Use Common Taxonomy Template.
get_template_part( 'assets/modern/partials/taxonomy/taxonomy', 'common' );

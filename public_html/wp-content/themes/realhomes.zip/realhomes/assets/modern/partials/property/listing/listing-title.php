<?php
/**
 * Listing: Title
 *
 * Title for listing pages.
 *
 * @since 	3.0.0
 * @package RH/modern
 */

?>



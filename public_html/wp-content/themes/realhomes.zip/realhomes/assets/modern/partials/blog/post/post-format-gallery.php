<?php
/**
 * Format: Gallery
 *
 * Gallery post format.
 *
 * @since 	3.0.0
 * @package RH/modern
 */

?>

<div class="listing-slider">
	<ul class="slides">
	    <?php list_gallery_images(); ?>
	</ul>
</div>

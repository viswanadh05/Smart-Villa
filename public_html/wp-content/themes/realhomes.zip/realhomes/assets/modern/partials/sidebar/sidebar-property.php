<?php
/**
 * Sidebar: Property
 *
 * @since 3.0.0
 * @package RH/modern
 */

?>

<aside class="rh_sidebar">
	<?php
	if ( ! dynamic_sidebar( 'property-sidebar' ) ) :
	endif;
	?>
</aside>
<!-- End Sidebar -->

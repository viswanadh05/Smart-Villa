<?php
/**
 * Banner: Header
 *
 * Banner for header.
 *
 * @since 	3.0.0
 * @package RH/modern
 */

?>

<section class="rh_banner rh_banner__default"></section>
<!-- /.rh_banner -->
